from pathlib import Path
from io import BytesIO
import base64, html, json, math, shutil
from PIL import Image, ImageCms
from reportlab.pdfgen import canvas
from reportlab.lib.colors import CMYKColor
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DictionaryObject, NameObject, NumberObject, TextStringObject, DecodedStreamObject, ArrayObject

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'source'
ASSETS = SRC / 'assets'
BUILD = ROOT / '_build'
ASSETS.mkdir(parents=True, exist_ok=True)
BUILD.mkdir(parents=True, exist_ok=True)
NATIVE = ASSETS / 'city-illustration-varied-v4.png'
if not NATIVE.exists():
    raise FileNotFoundError(NATIVE)
MM = 72 / 25.4
W, H = 841 * MM, 1189 * MM
PALETTE = {'paper':'#081D2B','ink':'#F1F5F3','muted':'#BFCFD6','rule':'#46606E','blue':'#78DCD4','violet':'#B6A4F2','coral':'#FFAD7D','green':'#A7D1AF','light':'#173444'}
ICC = Path(r'C:\Windows\System32\spool\drivers\color\RSWOP.icm')
RGBICC = Path(r'C:\Windows\System32\spool\drivers\color\sRGB Color Space Profile.icm')
rgbprof, cmykprof = ImageCms.getOpenProfile(str(RGBICC)), ImageCms.getOpenProfile(str(ICC))
def rgb(hexcolor):
    return tuple(int(hexcolor[i:i+2],16) for i in (1,3,5))
def inkcolor(key):
    p=Image.new('RGB',(1,1),rgb(PALETTE.get(key,key)))
    vals=ImageCms.profileToProfile(p,rgbprof,cmykprof,outputMode='CMYK',renderingIntent=1).getpixel((0,0))
    return CMYKColor(*(x/255 for x in vals))

FONTMAP={400:'Medium',600:'SemiBold',800:'Bold',900:'Bold'}
SVGWEIGHTS={400:500,600:600,800:700,900:700}
for weight,name in FONTMAP.items():
    pdfmetrics.registerFont(TTFont(f'KR{weight}',str(ASSETS/'fonts'/f'Pretendard-{name}.ttf')))
pdfmetrics.registerFont(TTFont('Display600',str(ASSETS/'fonts'/'SpaceGrotesk-SemiBold.ttf')))
pdfmetrics.registerFont(TTFont('Display500',str(ASSETS/'fonts'/'SpaceGrotesk-Medium.ttf')))

# Print-only colour conversion and sizing. Original generated image is preserved.
native=Image.open(NATIVE).convert('RGBA')
flat=Image.new('RGBA',native.size,rgb(PALETTE['paper'])+(255,))
flat.alpha_composite(native)
flat=flat.convert('RGB').resize((4800,3200),Image.Resampling.LANCZOS)
cmyk=ImageCms.profileToProfile(flat,rgbprof,cmykprof,outputMode='CMYK',renderingIntent=1)
CMYKIMG=ASSETS/'city-illustration-print-cmyk_v3.jpg'
cmyk.save(CMYKIMG,quality=98,subsampling=0,dpi=(160,160),icc_profile=ICC.read_bytes())
BG=ASSETS/'future-effects-v3.png'
bg_native=Image.open(BG).convert('RGB')
bg_print=bg_native.resize((5100,7211),Image.Resampling.LANCZOS)
bg_cmyk=ImageCms.profileToProfile(bg_print,rgbprof,cmykprof,outputMode='CMYK',renderingIntent=1)
BGC=ASSETS/'future-effects-print-cmyk_v3.jpg'
bg_cmyk.save(BGC,quality=94,subsampling=0,icc_profile=ICC.read_bytes())

rawpdf=BUILD/'poster-cmyk-raw_v3.pdf'
c=canvas.Canvas(str(rawpdf),pagesize=(W,H),pageCompression=1,enforceColorSpace='CMYK',initialFontName='KR400',initialFontSize=24)
c.setTitle('NEURO ROAD 2050 | AI 완전자율주행도로')
c.setAuthor('국민대학교 인공지능학과 Team E26-AI01-05')
c.setSubject('2026 유레카 프로젝트 A0 포스터 초안 03')
c.setCreator('NEURO ROAD 2050 poster production')
svg=[]
text_boxes=[]
def col(key): return PALETTE.get(key,key)
def rect(x,y,w,h,fill,stroke=None,lw=.5):
    c.setFillColor(inkcolor(fill))
    if stroke: c.setStrokeColor(inkcolor(stroke))
    c.setLineWidth(lw*MM)
    c.rect(x*MM,H-(y+h)*MM,w*MM,h*MM,fill=1,stroke=bool(stroke))
    svg.append(f'<rect x="{x*MM:.3f}" y="{y*MM:.3f}" width="{w*MM:.3f}" height="{h*MM:.3f}" fill="{col(fill)}"'+(f' stroke="{col(stroke)}" stroke-width="{lw*MM}"' if stroke else '')+'/>' )
def line(x1,y1,x2,y2,color='rule',lw=.35):
    c.setStrokeColor(inkcolor(color)); c.setLineWidth(lw*MM)
    c.line(x1*MM,H-y1*MM,x2*MM,H-y2*MM)
    svg.append(f'<line x1="{x1*MM:.3f}" y1="{y1*MM:.3f}" x2="{x2*MM:.3f}" y2="{y2*MM:.3f}" stroke="{col(color)}" stroke-width="{lw*MM:.3f}"/>')
def text(txt,x,y,size=28,weight=400,color='ink',width=None,align='left',display=False):
    font=('Display600' if weight>=600 else 'Display500') if display else f'KR{weight}'
    tw=pdfmetrics.stringWidth(txt,font,size)
    if width is not None and tw>width*MM+.2:
        raise ValueError(f'Text too wide ({tw/MM:.2f}>{width}mm): {txt}')
    if align=='right': x -= tw/MM
    if align=='center': x -= tw/(2*MM)
    asc=pdfmetrics.getAscent(font)*size/1000
    baseline=y*MM+asc
    c.setFillColor(inkcolor(color)); c.setFont(font,size)
    c.drawString(x*MM,H-baseline,txt)
    family='Space Grotesk' if display else 'Pretendard'
    svgweight=(600 if weight>=600 else 500) if display else SVGWEIGHTS[weight]
    svg.append(f'<text x="{x*MM:.3f}" y="{baseline:.3f}" font-family="{family}" font-size="{size}" font-weight="{svgweight}" fill="{col(color)}">{html.escape(txt)}</text>')
    text_boxes.append({'text':txt,'x_mm':x,'y_mm':y,'w_mm':tw/MM,'h_mm':size/MM,'size_pt':size})
    return tw/MM
def paragraph(txt,x,y,w,size=27,weight=400,color='ink',leading=1.4):
    out=[]
    for p in txt.split('\n'):
        if not p: out.append(''); continue
        current=''
        for char in p:
            cand=current+char
            if pdfmetrics.stringWidth(cand,f'KR{weight}',size)>w*MM and current:
                # Prefer a nearby word boundary without creating very short lines.
                cut=current.rfind(' ')
                if cut>=len(current)*.55:
                    out.append(current[:cut]); current=current[cut+1:]+char
                else:
                    out.append(current); current=char
            else: current=cand
        out.append(current.rstrip())
    for i,s in enumerate(out): text(s,x,y+i*size*leading/MM,size,weight,color,width=w)
    return y+len(out)*size*leading/MM
def label(txt,x,y,color='blue'):
    text(txt,x,y,24,600,color)
def badge(n,x,y):
    r=7.0
    c.setFillColor(inkcolor('blue')); c.circle(x*MM,H-y*MM,r*MM,fill=1,stroke=0)
    svg.append(f'<circle cx="{x*MM}" cy="{y*MM}" r="{r*MM}" fill="{col("blue")}"/>')
    text(n,x,y-4.5,25,800,'paper',align='center')
def shared_signal(points):
    c.saveState();c.setStrokeColor(inkcolor('blue'));c.setLineWidth(.42*MM);c.setDash(2.5*MM,1.8*MM)
    p=c.beginPath();p.moveTo(points[0][0]*MM,H-points[0][1]*MM)
    for x,y in points[1:]:p.lineTo(x*MM,H-y*MM)
    c.drawPath(p,stroke=1,fill=0);c.restoreState()
    coords=' '.join(f'{x*MM:.3f},{y*MM:.3f}' for x,y in points)
    svg.append(f'<polyline points="{coords}" fill="none" stroke="{col("blue")}" stroke-width="{.42*MM}" stroke-dasharray="{2.5*MM} {1.8*MM}"/>')

def curve_arrow(points,color='blue'):
    (x0,y0),(x1,y1),(x2,y2),(x3,y3)=points
    c.saveState(); c.setLineCap(1)
    c.setStrokeColor(inkcolor('paper')); c.setLineWidth(1.6*MM); c.setDash(); c.setStrokeAlpha(.28)
    c.bezier(x0*MM,H-y0*MM,x1*MM,H-y1*MM,x2*MM,H-y2*MM,x3*MM,H-y3*MM)
    c.setStrokeColor(inkcolor(color)); c.setStrokeAlpha(1); c.setLineWidth(.65*MM); c.setDash(2.5*MM,2.0*MM)
    c.bezier(x0*MM,H-y0*MM,x1*MM,H-y1*MM,x2*MM,H-y2*MM,x3*MM,H-y3*MM)
    c.setDash(); ang=math.atan2(y3-y2,x3-x2)
    left=(x3-6*math.cos(ang-.45),y3-6*math.sin(ang-.45))
    right=(x3-6*math.cos(ang+.45),y3-6*math.sin(ang+.45))
    p=c.beginPath();p.moveTo(x3*MM,H-y3*MM);p.lineTo(left[0]*MM,H-left[1]*MM);p.lineTo(right[0]*MM,H-right[1]*MM);p.close()
    c.setFillColor(inkcolor(color));c.drawPath(p,fill=1,stroke=0);c.restoreState()
    d=f'M {x0*MM},{y0*MM} C {x1*MM},{y1*MM} {x2*MM},{y2*MM} {x3*MM},{y3*MM}'
    svg.append(f'<path d="{d}" fill="none" stroke="{col("paper")}" stroke-width="{1.6*MM}" stroke-opacity="0.28" stroke-linecap="round"/>')
    svg.append(f'<path d="{d}" fill="none" stroke="{col(color)}" stroke-width="{.65*MM}" stroke-dasharray="{2.5*MM} {2*MM}" stroke-linecap="round"/>')
    svg.append(f'<polygon points="{x3*MM},{y3*MM} {left[0]*MM},{left[1]*MM} {right[0]*MM},{right[1]*MM}" fill="{col(color)}"/>')

rect(0,0,841,1189,'paper')
c.drawImage(str(BGC),0,0,width=W,height=H)
bgdata=base64.b64encode(BG.read_bytes()).decode('ascii')
svg.append(f'<image x="0" y="0" width="{W}" height="{H}" href="data:image/png;base64,{bgdata}" preserveAspectRatio="none"/>')
# A quiet vector backing keeps the fine-print region readable over the light trails.
c.saveState(); c.setFillAlpha(.58)
svg.append('<g opacity="0.58">')
rect(0,978,841,211,'paper')
svg.append('</g>')
c.restoreState()
line(34,24,807,24,'ink',.65)
text('KOOKMIN UNIVERSITY',34,32,25,800)
text('EUREKA PROJECT 2026',202,32,25,400,'muted')
text('TEAM E26-AI01-05',807,32,24,600,'blue',align='right')

title_size=222
while pdfmetrics.stringWidth('NEURO ROAD','Display600',title_size)>584*MM: title_size-=1
text('NEURO ROAD',31,62,title_size,600,width=590,display=True)
text('2050',807,78,136,500,'coral',align='right',display=True)
text('사람을 위한 길을, 도시가 함께 만든다',34,146,51,600,width=773)
text('AI 완전자율주행도로',35,174,29,600,'blue')
text('군체 안전망과 자기부상·충전·주차가 연결되는 미래',196,174,28,400,width=610)
text('국민대학교 인공지능학과',35,194,25,600)
text('최성우  양성현  최다령  이충범',807,194,25,400,align='right')
line(34,216,807,216,'ink',.5)

label('02 / 문제와 사용자',34,231)
text('보행자의 안전,',34,250,39,800)
text('이동자의 시간과 공간',34,268,39,800)
text('지금',344,239,24,600,'muted')
text('2050',344,270,24,800,'blue')
for x,old,new in [(435,'가려진 위험','공동 감지'),(578,'충전소 방문','주행 중 공급'),(723,'주차 탐색','접이식 보관')]:
    text(old,x,236,31,600,'muted',align='center')
    text(new,x,267,31,800,'ink',align='center')
line(414,257,794,257,'rule',.25)
line(34,301,807,301,'rule',.4)

label('03 / 우리가 상상한 미래',34,316)
text('도로가 사람의 걸음에 맞춰 공간을 준비한다',807,315,29,600,align='right')
ix,iy,iw,ih=95.5,385,650,650*2/3
c.drawImage(str(CMYKIMG),ix*MM,H-(iy+ih)*MM,width=iw*MM,height=ih*MM)
data=base64.b64encode(NATIVE.read_bytes()).decode('ascii')
svg.append(f'<image x="{ix*MM:.3f}" y="{iy*MM:.3f}" width="{iw*MM:.3f}" height="{ih*MM:.3f}" href="data:image/png;base64,{data}"/>')
def point(u,v):return(ix+iw*u,iy+ih*v)
shared_signal([point(.47,.535),point(.60,.49),point(.665,.45)])
shared_signal([point(.60,.49),point(.61,.625),point(.355,.675)])
text('청록 점선: 감지 정보 공유',807,331,18,400,'blue',align='right')
# Editable curved callouts connect four functions with their scenes.
curve_arrow([(164,388),(65,421),(143,598),point(.467,.56)],'blue')
curve_arrow([(689,388),(795,423),(690,515),point(.69,.49)],'violet')
curve_arrow([(159,802),(111,779),(166,748),point(.23,.823)],'coral')
curve_arrow([(699,802),(807,772),(802,659),point(.94,.59)],'green')
for n,title,sub,x,y,color in [
    ('01','공동 감각','사각지대를 함께 감지',34,352,'blue'),
    ('02','자기부상','바퀴 없이 떠서 이동',641,352,'violet'),
    ('03','달리는 충전','이동 중 전력 공급',34,771,'coral'),
    ('04','접히는 주차','빈 차를 접어 보관',641,771,'green')]:
    text(n,x,y,27,600,color,display=True)
    text(title,x+24,y-1,31,600,'ink')
    text(sub,x,y+17,23,400,'muted')
line(34,856,807,856,'ink',.45)

label('04 / 미래 기술과 작동 방식',34,868)
features=[('01','공동 감각','휴대기기·차량·도로가 감지해\n보행자 보호 공간을 확보한다.'),('02','자기부상','전자석으로 캡슐을 지탱하고\n리니어 모터로 이동한다.'),('03','달리는 충전','도로 아래 코일이 차량의\n수신 장치에 전력을 보낸다.'),('04','접히는 주차','빈 차의 좌석과 실내를 접어\n보관소에 자동으로 주차한다.')]
for i,(num,title,body) in enumerate(features):
    x=34+i*198
    text(num,x,890,27,600,['blue','violet','coral','green'][i],display=True)
    text(title,x+22,887,34,600,width=170)
    paragraph(body,x,908,180,26,400,leading=1.43)
    if i<3: line(x+189,891,x+189,939,'rule',.25)
text('AI 작동',34,951,23,600,'blue')
steps=[('함께 감지',184),('위험 예측',354),('공간 조율',524),('협력 제어',694)]
for i,(s,x) in enumerate(steps):
    text(s,x,949,26,600)
    if i<3:
        line(x+110,955,x+144,955,'muted',.45)
        line(x+139,952,x+144,955,'muted',.45)
        line(x+139,958,x+144,955,'muted',.45)
line(34,977,807,977,'ink',.45)

label('05 / 실현 가능성과 남은 질문',34,992)
text('현재의 근거',34,1012,25,800)
text('협력 인지·자기부상·무선충전·접이차 [1-4]',128,1012,24,400,width=370)
text('2050의 과제',34,1027,25,800)
text('통합 제어·전력손실·접이부 강도·비상전원 검증',128,1027,24,400,width=370)
paragraph('위치 오차·통신 단절에는 감속·정지한다.\n기기가 없는 사람도 감지하고, 위치정보는 최소 수집한다.\n무사고는 목표이며 실제 성능은 검증이 필요하다.',34,1049,465,24,400,leading=1.45)
line(518,992,518,1090,'rule',.3)
label('06 / 그 미래 속 우리',541,992)
paragraph('사람은 자신의 속도로 걷고,\n이동 중 시간을 자유롭게 쓴다.\n우리는 이동 AI·보안·시뮬레이션과\n사용자 경험을 설계하는 미래를 꿈꾼다.\nSW·AI가 경로와 전력을 함께 조율한다.',541,1012,266,24,400,leading=1.45)
line(34,1110,807,1110,'ink',.45)

label('07 / 참고자료·디자인 레퍼런스',34,1120)
refs=[('[1] FHWA · 협력 인지 (2025)',34,'https://highways.dot.gov/FHWA-HRT-25-092'),('[2] TSB · 자기부상 교통',253,'https://transportsystemboegl.com/en/vehicle/'),('[3] Michigan DOT · 무선충전 도로',437,'https://www.michigan.gov/mdot/travel/mobility/initiatives/wireless-charging-roadway'),('[4] MIT Media Lab · CityCar',659,'https://www-prod.media.mit.edu/projects/citycar/overview/')]
for s,x,url in refs:
    tw=text(s,x,1137,17,400,'muted')
    c.linkURL(url,(x*MM,H-1146*MM,(x+tw)*MM,H-1137*MM),relative=0,thickness=0)
design_refs=[
    ('Vinicius Valente / Isometric City', 'behance.net/gallery/41531361', 'https://www.behance.net/gallery/41531361/Isometric-City', 1152),
    ('Dust / Electricity Smart Cities', 'behance.net/gallery/162727095', 'https://www.behance.net/gallery/162727095/Electricity-Smart-Cities', 1164),
]
for title,short_url,url,y in design_refs:
    svg.append(f'<a href="{html.escape(url,quote=True)}">')
    tw=text(f'Behance  {title}  /  {short_url}',34,y,18,400,'muted',width=773)
    svg.append('</a>')
    c.linkURL(url,(34*MM,H-(y+9)*MM,(34+tw)*MM,H-y*MM),relative=0,thickness=0)

c.showPage(); c.save()
reader=PdfReader(rawpdf)
writer=PdfWriter(); writer.clone_document_from_reader(reader)
iccstream=DecodedStreamObject();iccstream.set_data(ICC.read_bytes());iccstream.update({NameObject('/N'):NumberObject(4)})
iccref=writer._add_object(iccstream)
intent=DictionaryObject({NameObject('/Type'):NameObject('/OutputIntent'),NameObject('/S'):NameObject('/GTS_PDFX'),NameObject('/OutputConditionIdentifier'):TextStringObject('SWOP Standard'),NameObject('/OutputCondition'):TextStringObject('Swop Standard - Agfa'),NameObject('/RegistryName'):TextStringObject('http://www.color.org'),NameObject('/Info'):TextStringObject('CMYK print draft; general SWOP profile, not certified PDF/X'),NameObject('/DestOutputProfile'):iccref})
writer._root_object[NameObject('/OutputIntents')]=ArrayObject([writer._add_object(intent)])
writer.add_metadata({'/Title':'NEURO ROAD 2050 - A0 CMYK Draft 03','/Author':'Kookmin University AI01-05','/Subject':'Editable text and isometric illustration. 2050 concept poster. Draft 03.'})
final=ROOT/'NEURO_ROAD_2050_A0_Draft03_CMYK.pdf'
with open(final,'wb') as f: writer.write(f)
svgtext=f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="841mm" height="1189mm" viewBox="0 0 {W} {H}">\n<title>NEURO ROAD 2050 - editable A0 poster, Draft 03</title>\n<desc>Text remains editable. Pretendard and Space Grotesk. Illustration generated with OpenAI. See source/revision03-notes.txt.</desc>\n'+ '\n'.join(svg)+'\n</svg>'
(ROOT/'NEURO_ROAD_2050_A0_Draft03_Editable.svg').write_text(svgtext,encoding='utf-8')
(BUILD/'text-layout_v3.json').write_text(json.dumps(text_boxes,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'pdf':str(final),'svg':str(ROOT/'NEURO_ROAD_2050_A0_Draft03_Editable.svg'),'image_print_pixels':flat.size,'image_effective_dpi':4800/(iw/25.4),'native_image_effective_dpi':1536/(iw/25.4),'text_boxes':len(text_boxes)},ensure_ascii=False))
