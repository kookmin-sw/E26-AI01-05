from pathlib import Path
from io import BytesIO
from functools import lru_cache
import base64, html, json, math, re
from PIL import Image, ImageCms
from reportlab.pdfgen import canvas
from reportlab.lib.colors import CMYKColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DictionaryObject, NameObject, NumberObject, TextStringObject, DecodedStreamObject, ArrayObject
from symbol_draw import draw_symbol

ROOT=Path(__file__).resolve().parent.parent
SRC=ROOT/'source'; AS=SRC/'assets'; BUILD=ROOT/'_build'
BUILD.mkdir(exist_ok=True)
MM=72/25.4
W,H=841,1189
P={'paper':'#FFFFFF','ink':'#17232B','navy':'#17374B','teal':'#087F83','muted':'#52646E','line':'#CFDFE3','pale':'#EEF7F7','soft':'#F6F8FA','white':'#FFFFFF'}
rgbprof=ImageCms.getOpenProfile(str(AS/'profiles/srgb.icc'))
cmykprof=ImageCms.getOpenProfile(str(AS/'profiles/print-cmyk.icc'))
ICC=(AS/'profiles/print-cmyk.icc').read_bytes()
for name,file in [('Body','Pretendard-Medium.ttf'),('Semi','Pretendard-SemiBold.ttf'),('Bold','Pretendard-Bold.ttf'),('Display','SpaceGrotesk-SemiBold.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(AS/'fonts'/file)))

@lru_cache(None)
def ink(key):
    if key=='ink': return CMYKColor(0,0,0,.94)
    if key in ('white','paper'): return CMYKColor(0,0,0,0)
    hx=P.get(key,key); rgb=tuple(int(hx[i:i+2],16) for i in (1,3,5))
    v=ImageCms.profileToProfile(Image.new('RGB',(1,1),rgb),rgbprof,cmykprof,outputMode='CMYK',renderingIntent=1).getpixel((0,0))
    return CMYKColor(*(a/255 for a in v))

def color(key): return P.get(key,key)
raw=BytesIO()
c=canvas.Canvas(raw,pagesize=(W*MM,H*MM),pageCompression=1,enforceColorSpace='CMYK',initialFontName='Body')
c.setTitle('NEURO ROAD 2050 - A0 Redesign Draft 07')
c.setAuthor('Kookmin University E26-AI01-05')
c.setSubject('Five features; bright editorial poster; 2026 Eureka Project')
c.scale(MM,MM)
svg=[]; boxes=[]; imgs=[]

def rect(x,y,w,h,fill='white',stroke=None,r=0,lw=.35):
    c.setFillColor(ink(fill)); c.setLineWidth(lw)
    if stroke:c.setStrokeColor(ink(stroke))
    c.roundRect(x,H-y-h,w,h,r,stroke=bool(stroke),fill=1)
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{color(fill)}"'+(f' stroke="{color(stroke)}" stroke-width="{lw}"' if stroke else '')+'/>')

def line(x1,y1,x2,y2,col='line',lw=.4):
    c.setStrokeColor(ink(col));c.setLineWidth(lw);c.line(x1,H-y1,x2,H-y2)
    svg.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{color(col)}" stroke-width="{lw}"/>')

def text(s,x,y,size=28,font='Body',col='ink',width=None,align='left'):
    tw=pdfmetrics.stringWidth(s,font,size)/MM
    if width is not None and tw>width+.15: raise ValueError(f'Text exceeds width {tw:.2f}/{width}: {s}')
    if align=='right':x-=tw
    if align=='center':x-=tw/2
    base=y+pdfmetrics.getAscent(font)*size/1000/MM
    c.setFillColor(ink(col));c.setFont(font,size/MM);c.drawString(x,H-base,s)
    fam='Space Grotesk' if font=='Display' else 'Pretendard'
    wt={'Body':500,'Semi':600,'Bold':700,'Display':600}[font]
    svg.append(f'<text x="{x:.3f}" y="{base:.3f}" fill="{color(col)}" font-family="{fam}" font-weight="{wt}" font-size="{size/MM:.3f}">{html.escape(s)}</text>')
    boxes.append({'text':s,'x_mm':x,'y_mm':y,'w_mm':tw,'h_mm':size/MM,'size_pt':size})
    return tw

def paragraph(s,x,y,w,size=26,font='Body',col='ink',leading=1.35):
    for i,row in enumerate(s.split('\n')):text(row,x,y+i*size*leading/MM,size,font,col,w)

def circle(x,y,r,fill='teal',stroke=None,lw=.4):
    c.setFillColor(ink(fill));c.setLineWidth(lw)
    if stroke:c.setStrokeColor(ink(stroke))
    c.circle(x,H-y,r,fill=1,stroke=bool(stroke))
    svg.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color(fill)}"'+(f' stroke="{color(stroke)}" stroke-width="{lw}"' if stroke else '')+'/>')

def section(n,title,y,right=None):
    rect(28,y,20,14,'teal',r=3)
    text(n,38,y+2.4,23,'Display','white',align='center')
    text(title,55,y+.1,33,'Bold')
    if right:text(right,813,y+2.5,24,'Body','muted',align='right')

def rpath(x,y,w,h,r):
    p=c.beginPath(); b=H-y-h; k=.55228475
    p.moveTo(x+r,b);p.lineTo(x+w-r,b);p.curveTo(x+w-r+k*r,b,x+w,b+r-k*r,x+w,b+r)
    p.lineTo(x+w,b+h-r);p.curveTo(x+w,b+h-r+k*r,x+w-r+k*r,b+h,x+w-r,b+h)
    p.lineTo(x+r,b+h);p.curveTo(x+r-k*r,b+h,x,b+h-r+k*r,x,b+h-r)
    p.lineTo(x,b+r);p.curveTo(x,b+r-k*r,x+r-k*r,b,x+r,b);p.close();return p

def art(name,x,y,w,h,r=4):
    f=AS/name; im=Image.open(f).convert('RGB'); native=im.size
    cm=ImageCms.profileToProfile(im,rgbprof,cmykprof,outputMode='CMYK',renderingIntent=1)
    dst=BUILD/(f.stem+'-print.jpg');cm.save(dst,quality=94,subsampling=0,icc_profile=ICC)
    c.saveState();c.clipPath(rpath(x,y,w,h,r),fill=0,stroke=0);c.drawImage(str(dst),x,H-y-h,w,h);c.restoreState()
    data=base64.b64encode(f.read_bytes()).decode('ascii'); cid=f'clip-{len(imgs)}'
    svg.append(f'<defs><clipPath id="{cid}"><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}"/></clipPath></defs><image x="{x}" y="{y}" width="{w}" height="{h}" preserveAspectRatio="none" href="data:image/png;base64,{data}" clip-path="url(#{cid})"/>')
    imgs.append({'file':name,'source_file_pixels':native,'print_pixels':im.size,'placement_mm':[w,h],'stored_dpi':[im.width/(w/25.4),im.height/(h/25.4)],'provenance':'Real-ESRGAN x4plus reconstruction from 1672x941; see upscale-notes.txt' if name=='future-scene.png' else 'Original generated raster; no resizing'})

def symbol(key,x,y,w,h):
    draw_symbol(c,key,x,H-y-h,w,h)
    source=(AS/'symbols'/f'{key}.svg').read_text(encoding='utf-8')
    inner=re.search(r'<svg[^>]*>(.*)</svg>',source,re.S).group(1)
    svg.append(f'<svg x="{x}" y="{y}" width="{w}" height="{h}" viewBox="0 0 240 140" preserveAspectRatio="xMidYMid meet">{inner}</svg>')

def connector(points):
    c.saveState();c.setLineCap(1);c.setStrokeColor(ink('white'));c.setLineWidth(1.8)
    p=c.beginPath();p.moveTo(points[0][0],H-points[0][1])
    for x,y in points[1:]:p.lineTo(x,H-y)
    c.drawPath(p,stroke=1);c.setStrokeColor(ink('teal'));c.setLineWidth(.65);c.drawPath(p,stroke=1);c.restoreState()
    pts=' '.join(f'{x},{y}' for x,y in points)
    svg.append(f'<polyline points="{pts}" fill="none" stroke="white" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><polyline points="{pts}" fill="none" stroke="{color("teal")}" stroke-width=".65" stroke-linecap="round" stroke-linejoin="round"/>')
    circle(*points[-1],2.2,'teal','white',.5)

def curve(points,col='teal',lw=1.2,dash=None):
    c.saveState();c.setLineCap(1);c.setLineJoin(1);c.setStrokeColor(ink(col));c.setLineWidth(lw);c.setDash(dash or [])
    p=c.beginPath();p.moveTo(points[0][0],H-points[0][1]);p.curveTo(*[v for px,py in points[1:] for v in (px,H-py)])
    c.drawPath(p,stroke=1);c.restoreState()
    d=f'M {points[0][0]} {points[0][1]} C '+' '.join(f'{px} {py}' for px,py in points[1:])
    svg.append(f'<path d="{d}" fill="none" stroke="{color(col)}" stroke-width="{lw}" stroke-linecap="round"'+(f' stroke-dasharray="{" ".join(map(str,dash))}"' if dash else '')+'/>')

def wireless_node(cx,cy,label,target):
    # Vector explanation layer, keeping the high-resolution raster unchanged.
    connector([(cx,cy+10),(cx,cy+22),target])
    circle(cx,cy,10.5,'white','teal',.8)
    for dx,dy,peak in [(7,-1,-6),(4.7,1.8,-1.5),(2.3,4,2.1)]:
        curve([(cx-dx,cy+dy),(cx-dx*.5,cy+peak),(cx+dx*.5,cy+peak),(cx+dx,cy+dy)],lw=1.25)
    circle(cx,cy+6.3,1.25,'teal')
    rect(cx-24,cy+12,48,11,'white',r=2)
    text(label,cx,cy+13.6,17.5,'Semi','teal',align='center')

def shared_network():
    paths=[
      [(130,524),(168,491),(209,485),(247,487)],
      [(247,487),(275,474),(306,465),(333,469)],
      [(130,524),(148,470),(247,447),(333,469)],
    ]
    for pts in paths:curve(pts,'white',3.2)
    for pts in paths:curve(pts,'teal',1.5,(3.2,3.2))
    wireless_node(130,524,'차량',(130,558))
    wireless_node(247,487,'보행자 기기',(249,524))
    wireless_node(333,469,'도로 센서',(329,495))
    rect(151,448,146,14,'white','line',3,.35)
    text('무선으로 위치·위험 정보 공유',224,450.3,20,'Semi','teal',align='center')

def callout(n,title,sub,key,x,y,w,target=None,via=None):
    if target:
        start=(x+w/2,y+54 if target[1]>y+54 else y)
        connector([start]+(via or [])+[target])
    rect(x,y,w,54,'white','line',4,.35)
    circle(x+11,y+12,6.6)
    text(str(n),x+11,y+7.7,25,'Display','white',align='center')
    text(title,x+23,y+5,30,'Bold','ink',w-82)
    paragraph(sub,x+9,y+24,w-72,23,'Body','muted',1.3)
    line(x+w-62,y+10,x+w-62,y+44,'line',.45)
    symbol(key,x+w-58,y+13,51,31)

# Subtle print-native gradient: very pale cyan at one corner, lilac at the other.
# Type, rules and symbols remain vector; all PDF shading colours are CMYK.
bg_colors=['#EAF6FC','#FFFFFF','#FFFFFF','#F0EDFA']
bg_positions=[0,.28,.66,1]
c.saveState();c.linearGradient(0,0,W,H,[ink(a) for a in bg_colors],bg_positions);c.restoreState()
stops=''.join(f'<stop offset="{p*100:g}%" stop-color="{co}"/>' for p,co in zip(bg_positions,bg_colors))
svg.append(f'<defs><linearGradient id="page-aura" x1="0%" y1="100%" x2="100%" y2="0%">{stops}</linearGradient></defs><rect x="0" y="0" width="{W}" height="{H}" fill="url(#page-aura)"/>')
text('2026 EUREKA PROJECT',28,18,20,'Display','navy')
text('국민대학교 인공지능학과  |  E26-AI01-05',813,18,20,'Semi','muted',align='right')

# 01. Title and summary; a distinct second viewpoint appears only here.
section('01','제목 및 요약',39)
art('title-scene.png',503,39,310,142,5)
title_size=138
while pdfmetrics.stringWidth('NEURO ROAD','Display',title_size)/MM>462:title_size-=1
text('NEURO ROAD',27,66,title_size,'Display','navy',462)
text('2050',28,115,78,'Display','teal')
text('AI 완전자율주행도로',164,128,36,'Bold','ink',316)
text('사람을 위한 길을, 도시가 함께 만든다',28,151,38,'Semi','ink',465)
text('안전·에너지·공간을 함께 조율하는 미래의 길',28,174,27,'Body','muted',465)
line(28,196,813,196)

# 02. Independent evidence cards: different populations, not a comparison chart.
section('02','문제와 사용자',207,'현재의 문제를 보여주는 국내 통계·설문')
problems=[
    ('보행자 · 보행 안전','920','명','2024년 국내 보행자\n교통사고 사망자',
     '전국 경찰접수 통계 · 2024년',
     '출처: 경찰청 / 통계청, 2025',
     'https://kostat.go.kr/boardDownload.es?bid=10820&list_no=438832&seq=1'),
    ('전기차 이용자 · 충전 불확실성','73','%','급속충전 10회 중 1회 이상\n충전 불가능 경험을 보고한 응답자',
     '국내 전기차 보유자 1,809명 · 2025년',
     '출처: 컨슈머인사이트, 충전 경험 조사',
     'https://consumerinsight.co.kr/boardView?id=pr4_list&no=3822&schFlag=0'),
    ('운전자 · 주차로 인한 시간 낭비','86.9','%','주차 문제로 목적지 도착 후에도\n시간을 낭비한 적이 있다고 응답',
     '전국 만 19-59세 운전 경험자 1,000명 · 2024년',
     '출처: 사례뉴스 / 엠브레인 조사',
     'https://v.daum.net/v/6kGdrS6FvS'),
]
cw=(785-24)/3
for i,(who,metric,unit,body,sample,source,url) in enumerate(problems):
    x=28+i*(cw+12)
    rect(x,233,cw,95,'soft','line',5)
    text(who,x+12,242,23,'Semi','teal',cw-24)
    metric_w=text(metric,x+12,254,66,'Display','teal')
    text(unit,x+16+metric_w,265,31,'Bold','teal')
    paragraph(body,x+12,283,cw-24,25,'Semi','ink',1.22)
    text(sample,x+12,307,18.5,'Body','muted',cw-24)
    svg.append(f'<a href="{html.escape(url)}">')
    tw=text(source,x+12,317,17,'Body','muted',cw-24)
    svg.append('</a>')
    c.linkURL(url,(x+12,H-325,x+12+tw,H-317),relative=1,thickness=0)

# 03. Largest panel, with five concise editable labels over the illustration.
section('03','미래 장면',336,'2050년, 도로가 사람을 위해 공간을 준비한다')
art('future-scene.png',28,362,785,442,5)
shared_network()
callout(1,'함께 보는 도로','사람·차량·센서가 정보를 공유해\n횡단 전에 함께 감속·정지한다.','sense',42,378,257)
callout(5,'살아 움직이는 도로','도로 모듈이 펼쳐져 길이 넓어지고,\n다시 접히면 도로 폭이 줄어든다.','lanes',333,378,258,(692,475),[(604,447),(655,456)])
callout(3,'달리며 충전','도로 코일에서 전력을 받아\n달리는 동안 배터리를 보충한다.','charge',42,738,237,(169,711))
callout(2,'바퀴 없는 이동','전용 도로의 전자석으로 떠서\n리니어 모터의 힘으로 이동한다.','levitate',295,738,245,(450,660))
callout(4,'접히는 주차','사람이 내린 뒤 빈 차체를 접어\n작은 공간에 스스로 주차한다.','fold',556,738,243,(706,680))
rect(28,810,785,15,'pale',r=3)
text('사람은 자신의 속도로 걷고, 이동 중 시간을 자유롭게 쓴다.',420.5,812.6,28,'Semi','navy',align='center')

# 04. Simple native-vector symbols; images are confined to the two scene areas.
section('04','기술 방식',839,'그림 속 1-5번을 움직이는 원리')
features=[
    ('sense','공동 감각','차량·도로·휴대기기가\n위험 정보를 공유하고\n주변 차량을 함께 제어한다.'),
    ('levitate','자기부상','전자석으로 차체를 띄우고\n리니어 모터로 추진한다.\n전용 유도로에서 운행한다.'),
    ('charge','달리는 충전','도로 코일이 전력을 보내\n이동 중 배터리를 보충한다.\n공급 중단 시 배터리를 쓴다.'),
    ('fold','접히는 주차','무인·정지 상태를 확인한 뒤\n좌석과 가변 차체를 접어\n자동 보관소에 들어간다.'),
    ('lanes','살아 움직이는 도로','접이식·슬라이딩 모듈로\n도로 폭을 넓히거나 줄인다.\n구간을 비운 뒤 AI가 제어한다.'),
]
fw=(785-4*10)/5
for i,(key,title,body) in enumerate(features):
    x=28+i*(fw+10)
    rect(x,865,fw,143,'pale' if i%2==0 else 'soft','line',5)
    circle(x+12,879,6.1)
    text(str(i+1),x+12,874.9,24,'Display','white',align='center')
    text(title,x+24,873.7,26 if i==4 else 30,'Bold','ink',fw-32)
    symbol(key,x+10,891,fw-20,64)
    paragraph(body,x+10,965,fw-20,23.5,'Body','ink',1.3)
text('AI 협력 흐름',28,1018,23,'Semi','teal')
text('함께 감지  →  위험 예측  →  공간 조율  →  협력 제어',452,1016.8,27,'Semi','navy',align='center')

# 05. Open questions, not unmeasured performance claims.
section('05','검증 질문',1042,'현재의 기술을 연결해, 미래의 가능성을 검토한다')
questions=[
    ('끊겨도 안전할까?','기기 없는 사람도 감지하고\n오류에는 감속·정지할 수 있을까?'),
    ('전력은 충분할까?','전송 손실·간섭·정전 상황에서\n비상전원을 확보할 수 있을까?'),
    ('변형해도 안전할까?','펼친 도로의 하중·이음부와\n반복 접힘의 내구성을 검증한다.'),
    ('정보와 책임은?','위치정보를 어떻게 보호하고,\n사고 시 누가 책임질까?'),
]
qw=(785-3*12)/4
for i,(title,body) in enumerate(questions):
    x=28+i*(qw+12)
    line(x,1066,x+qw,1066,'teal',.75)
    text(title,x,1072,28,'Bold','ink',qw)
    paragraph(body,x,1090,qw,23,'Body','muted',1.3)

line(28,1118,813,1118)
text('미래 속 우리',28,1124,24,'Bold','teal')
text('이동 AI·보안·시뮬레이션·사용자 경험을 설계하는 미래를 꿈꾼다.',111,1124,24,'Body','ink',702)
text('국민대학교 인공지능학과  |  양성현 · 최다령 · 이충범',28,1138,23,'Semi')
text('2050 미래 구상 · 무사고는 목표이며 통합 검증이 필요하다.',813,1139,18,'Body','muted',align='right')
text('AI 활용: Open AI 이미지 생성 / Real-ESRGAN 해상도 보강',28,1150,18,'Body','muted',785)

refs=[
    ('FHWA · 협력 인지','https://highways.dot.gov/FHWA-HRT-25-092'),
    ('TSB · 자기부상','https://transportsystemboegl.com/en/vehicle/'),
    ('Michigan DOT · 무선충전','https://www.michigan.gov/mdot/travel/mobility/initiatives/wireless-charging-roadway'),
    ('MIT CityCar · 접이차','https://www-prod.media.mit.edu/projects/citycar/overview/'),
]
for i,(title,url) in enumerate(refs):
    x=28+i*159; y=1162
    svg.append(f'<a href="{html.escape(url)}">')
    tw=text(f'[{i+1}] {title}',x,y,17,'Body','muted')
    svg.append('</a>');c.linkURL(url,(x,H-y-8,x+tw,H-y),relative=1,thickness=0)
text('[5] 접이식 도로 · 팀 미래 구상',28+4*159,1162,17,'Body','muted')
designs=[('포스터 레퍼런스 참조: Behance','https://www.behance.net/'),('디자인 도구: Canva','https://www.canva.com/')]
for i,(title,url) in enumerate(designs):
    x=28+i*290;y=1172
    svg.append(f'<a href="{html.escape(url)}">');tw=text(title,x,y,16,'Body','muted');svg.append('</a>')
    c.linkURL(url,(x,H-y-8,x+tw,H-y),relative=1,thickness=0)

c.showPage();c.save()
writer=PdfWriter();writer.clone_document_from_reader(PdfReader(BytesIO(raw.getvalue())))
stream=DecodedStreamObject();stream.set_data(ICC);stream.update({NameObject('/N'):NumberObject(4)})
intent=DictionaryObject({NameObject('/Type'):NameObject('/OutputIntent'),NameObject('/S'):NameObject('/GTS_PDFX'),NameObject('/OutputConditionIdentifier'):TextStringObject('SWOP Standard'),NameObject('/Info'):TextStringObject('CMYK concept poster draft; not certified PDF/X'),NameObject('/DestOutputProfile'):writer._add_object(stream)})
writer._root_object[NameObject('/OutputIntents')]=ArrayObject([writer._add_object(intent)])
writer.add_metadata({'/Title':'NEURO ROAD 2050 - A0 Redesign Draft 07','/Author':'Kookmin University E26-AI01-05'})
pdf=ROOT/'NEURO_ROAD_2050_A0_Redesign_Draft07_CMYK.pdf'
with pdf.open('wb') as f:writer.write(f)
svgfile=ROOT/'NEURO_ROAD_2050_A0_Redesign_Draft07_Editable.svg'
svgfile.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="841mm" height="1189mm" viewBox="0 0 841 1189"><title>NEURO ROAD 2050 - Draft 07</title><desc>Editable vector text and diagrams. See source/production-notes.txt for image generation and font details.</desc>\n'+ '\n'.join(svg)+'\n</svg>',encoding='utf-8')
(BUILD/'layout.json').write_text(json.dumps(boxes,ensure_ascii=False,indent=2),encoding='utf-8')
(BUILD/'image-resolution.json').write_text(json.dumps(imgs,indent=2),encoding='utf-8')
assert all(b['x_mm']>=0 and b['y_mm']>=0 and b['x_mm']+b['w_mm']<=W+.1 and b['y_mm']+b['h_mm']<=H for b in boxes)
print(json.dumps({'pdf':str(pdf),'svg':str(svgfile),'text_items':len(boxes),'images':imgs},ensure_ascii=True))
