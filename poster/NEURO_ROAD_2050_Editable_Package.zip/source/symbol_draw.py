"""Five matching SVG / CMYK ReportLab symbols, with shared vector geometry.

Usage: draw_symbol(canvas, 'sense', x, y, width, height).
All five arguments use the canvas's CURRENT coordinate units. If the parent
canvas has already been scaled to millimetres, pass millimetres; otherwise pass
points (or values multiplied by reportlab.lib.units.mm). (x, y) is the lower-left
corner. The 240 x 140 design is centered and contained in that box, never stretched.
The function restores canvas state and uses only CMYK colors, supporting
Canvas(..., enforceColorSpace='CMYK'). No fonts, raster images, or dependencies
other than ReportLab are used. Running this file writes the five sibling SVGs.
"""

from pathlib import Path
from xml.etree import ElementTree as ET

SIZE = (240, 140)
HEX = {'navy': '#17374B', 'teal': '#087F83', 'pale': '#E5F4F3', 'white': '#FFFFFF'}
CMYK = {
    'navy': (0.693333, 0.266667, 0, 0.705882),
    'teal': (0.938931, 0.030534, 0, 0.486275),
    'pale': (0.061475, 0, 0.004098, 0.043137),
    'white': (0, 0, 0, 0),
}


def path(commands, stroke='navy', fill=None, width=6, dash=None):
    return {'kind': 'path', 'commands': commands, 'stroke': stroke,
            'fill': fill, 'width': width, 'dash': dash}


def ellipse(cx, cy, rx, ry=None, stroke='navy', fill=None, width=6):
    return {'kind': 'ellipse', 'box': (cx-rx, cy-(ry or rx), cx+rx, cy+(ry or rx)),
            'stroke': stroke, 'fill': fill, 'width': width, 'dash': None}


def line(x1, y1, x2, y2, color='navy', width=6, dash=None):
    return path([('M', x1, y1), ('L', x2, y2)], color, width=width, dash=dash)


def arrow(x1, y1, x2, y2, color='teal', head=8, width=6):
    from math import hypot
    length = hypot(x2-x1, y2-y1)
    ux, uy = (x2-x1)/length, (y2-y1)/length
    px, py = -uy, ux
    return [line(x1, y1, x2, y2, color, width),
            path([('M', x2-ux*head+px*head*.7, y2-uy*head+py*head*.7),
                  ('L', x2, y2),
                  ('L', x2-ux*head-px*head*.7, y2-uy*head-py*head*.7)],
                 color, width=width)]


def pod(x, y, w, h):
    """Same wheel-free capsule silhouette, scaled for every scene."""
    def p(a, b):
        return x+w*a, y+h*b
    outline = [('M', *p(.13, 1)),
               ('C', *p(.01, 1), *p(-.015, .82), *p(.035, .6)),
               ('C', *p(.12, .19), *p(.3, 0), *p(.57, 0)),
               ('C', *p(.83, 0), *p(.95, .26), *p(.985, .62)),
               ('C', *p(1.02, .86), *p(.95, 1), *p(.85, 1)), ('Z',)]
    canopy = [('M', *p(.18, .58)),
              ('C', *p(.28, .16), *p(.67, .1), *p(.83, .52)),
              ('L', *p(.18, .58)), ('Z',)]
    return [path(outline, 'navy', 'white'),
            path(canopy, 'teal', 'pale', 5),
            line(*p(.16, .81), *p(.82, .81), color='navy', width=5)]


def geometry(key):
    if key == 'sense':
        # Local sensor shares its observations with a person and a vehicle.
        items = [path([('M', 111, 35), ('C', 82, 29, 55, 33, 40, 47)],
                      'teal', width=6, dash=(3, 9)),
                 path([('M', 138, 35), ('C', 168, 32, 188, 43, 191, 67)],
                      'teal', width=6, dash=(3, 9)),
                 ellipse(124, 31, 11, stroke='teal', fill='pale'),
                 line(124, 43, 124, 58), line(113, 58, 135, 58),
                 ellipse(36, 64, 9, fill='white'),
                 line(36, 77, 36, 99),
                 path([('M', 17, 91), ('L', 36, 80), ('L', 54, 91)]),
                 path([('M', 21, 121), ('L', 36, 99), ('L', 51, 121)]),
                 line(62, 104, 94, 104, 'teal', dash=(3, 9))]
        return items + pod(104, 74, 108, 47)
    if key == 'levitate':
        items = pod(66, 25, 108, 49)
        items += [line(22, 119, 218, 119), line(38, 130, 202, 130, 'teal')]
        items += arrow(88, 108, 88, 88) + arrow(152, 108, 152, 88)
        return items
    if key == 'charge':
        items = pod(67, 15, 106, 47)
        items += [line(100, 73, 140, 73, 'teal'),
                  ellipse(120, 119, 54, 10, 'teal', 'pale', 5),
                  ellipse(120, 119, 35, 6, 'teal', None, 5),
                  line(22, 132, 218, 132),
                  path([('M', 127, 79), ('L', 111, 96), ('L', 123, 96),
                        ('L', 114, 111), ('L', 135, 91), ('L', 122, 91),
                        ('L', 127, 79), ('Z',)], None, 'teal')]
        return items
    if key == 'fold':
        items = pod(13, 57, 91, 45) + pod(159, 57, 57, 45)
        items += arrow(115, 79, 144, 79, head=7)
        items += arrow(155, 34, 176, 34, head=7)
        items += arrow(221, 34, 200, 34, head=7)
        items += [line(14, 119, 103, 119, 'teal', 5),
                  line(14, 114, 14, 124, 'teal', 5),
                  line(103, 114, 103, 124, 'teal', 5),
                  line(160, 119, 216, 119, 'teal', 5),
                  line(160, 114, 160, 124, 'teal', 5),
                  line(216, 114, 216, 124, 'teal', 5)]
        return items
    if key == 'lanes':
        # Two physical deck states: side modules stowed upright, then flat.
        # Horizontal motion arrows show width change, not traffic direction.
        items = [
            path([('M', 26, 45), ('L', 17, 36), ('L', 17, 108),
                  ('L', 26, 117), ('Z',)], 'teal', 'pale', 5),
            path([('M', 70, 45), ('L', 79, 36), ('L', 79, 108),
                  ('L', 70, 117), ('Z',)], 'teal', 'pale', 5),
            path([('M', 26, 45), ('L', 70, 45), ('L', 70, 117),
                  ('L', 26, 117), ('Z',)], 'navy', 'white', 6),
            line(48, 52, 48, 110, 'navy', 4.5, (8, 9)),
            path([('M', 133, 45), ('L', 231, 45), ('L', 231, 117),
                  ('L', 133, 117), ('Z',)], 'navy', 'pale', 6),
            path([('M', 160, 45), ('L', 204, 45), ('L', 204, 117),
                  ('L', 160, 117), ('Z',)], 'teal', 'white', 5),
            line(182, 52, 182, 110, 'navy', 4.5, (8, 9)),
        ]
        for y in (69, 93):
            items += [line(133, y, 160, y, 'teal', 4),
                      line(204, y, 231, y, 'teal', 4)]
        # Inward over the compact state, outward over the extended state.
        items += arrow(14, 21, 36, 21, head=6, width=5)
        items += arrow(82, 21, 60, 21, head=6, width=5)
        items += arrow(171, 21, 143, 21, head=6, width=5)
        items += arrow(193, 21, 221, 21, head=6, width=5)
        # Reversible mechanical deployment.
        items += arrow(93, 72, 120, 72, head=6, width=5)
        items += arrow(120, 92, 93, 92, head=6, width=5)
        return items
    raise ValueError(f'Unknown symbol {key!r}; expected {", ".join(KEYS)}')


KEYS = ('sense', 'levitate', 'charge', 'fold', 'lanes')


def draw_symbol(c, key, x, y, w, h):
    """Draw within a lower-left canvas box, preserving aspect and CMYK color."""
    from reportlab.lib.colors import CMYKColor
    if w <= 0 or h <= 0:
        raise ValueError('Symbol width and height must be positive')
    shapes = geometry(key)
    scale = min(w / SIZE[0], h / SIZE[1])
    c.saveState()
    try:
        c.translate(x + (w-SIZE[0]*scale)/2, y + (h+SIZE[1]*scale)/2)
        c.scale(scale, -scale)
        c.setLineCap(1)
        c.setLineJoin(1)
        for shape in shapes:
            stroke, fill = shape['stroke'], shape['fill']
            if stroke:
                c.setStrokeColor(CMYKColor(*CMYK[stroke]))
            if fill:
                c.setFillColor(CMYKColor(*CMYK[fill]))
            c.setLineWidth(shape['width'])
            c.setDash(shape['dash'] or [])
            if shape['kind'] == 'ellipse':
                c.ellipse(*shape['box'], stroke=bool(stroke), fill=bool(fill))
            else:
                p = c.beginPath()
                for cmd in shape['commands']:
                    if cmd[0] == 'M': p.moveTo(*cmd[1:])
                    elif cmd[0] == 'L': p.lineTo(*cmd[1:])
                    elif cmd[0] == 'C': p.curveTo(*cmd[1:])
                    elif cmd[0] == 'Z': p.close()
                c.drawPath(p, stroke=bool(stroke), fill=bool(fill))
    finally:
        c.restoreState()


def svg_text(key):
    def n(value):
        return f'{value:g}'
    root = ET.Element('svg', {'xmlns': 'http://www.w3.org/2000/svg',
                             'viewBox': '0 0 240 140', 'width': '240', 'height': '140',
                             'fill': 'none', 'stroke-linecap': 'round',
                             'stroke-linejoin': 'round'})
    for shape in geometry(key):
        attrs = {'stroke': HEX[shape['stroke']] if shape['stroke'] else 'none',
                 'fill': HEX[shape['fill']] if shape['fill'] else 'none',
                 'stroke-width': n(shape['width'])}
        if shape['dash']:
            attrs['stroke-dasharray'] = ' '.join(map(n, shape['dash']))
        if shape['kind'] == 'ellipse':
            x1, y1, x2, y2 = shape['box']
            attrs.update(cx=n((x1+x2)/2), cy=n((y1+y2)/2),
                         rx=n((x2-x1)/2), ry=n((y2-y1)/2))
            ET.SubElement(root, 'ellipse', attrs)
        else:
            attrs['d'] = ' '.join(cmd[0] + (' ' + ' '.join(map(n, cmd[1:]))
                                           if len(cmd)>1 else '')
                                  for cmd in shape['commands'])
            ET.SubElement(root, 'path', attrs)
    ET.indent(root, space='  ')
    return ET.tostring(root, encoding='unicode') + '\n'


def write_svgs(directory=None):
    directory = Path(directory) if directory else Path(__file__).parent/'assets'/'symbols'
    directory.mkdir(parents=True, exist_ok=True)
    for key in KEYS:
        output = directory / f'{key}.svg'
        output.write_text(svg_text(key), encoding='utf-8')
        ET.parse(output)
    return directory


if __name__ == '__main__':
    print(write_svgs())
